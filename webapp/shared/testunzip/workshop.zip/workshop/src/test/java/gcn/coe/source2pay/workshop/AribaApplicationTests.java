package gcn.coe.source2pay.workshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AribaApplicationTests {

	@Test
	void contextLoads() {
	}

}
